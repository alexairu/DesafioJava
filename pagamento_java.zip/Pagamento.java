public interface Pagamento {
    void realizarPagamento(double valor);
}
